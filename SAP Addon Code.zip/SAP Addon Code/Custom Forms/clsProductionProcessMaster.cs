using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;

namespace SAPAddonCode
{
    class clsProductionProcessMaster : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        const string formMenuUID = "PROD_PROC_MASTER";
        const string formTypEx = "PROD_PROC_MASTER";
        const string formTitle = "Production Process Master";

        const string headerTable = "@PROD_PROC_MASTER";
        const string objType = "PROD_PROC_MASTER";
        string CFL_BP = nameof(CFL_BP);

        const string processCodeUDF = "U_PrcCode";
        const string processCodeUID = "PrcCode";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string processCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(processCodeUDF, 0).ToString().Trim();
                                    if (processCode == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please enter process code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    if (oForm.Mode == BoFormMode.fm_ADD_MODE)
                                    {
                                        string isExists = objclsComman.SelectRecord("SELECT 1 FROM [" + headerTable + "] WHERE " + processCodeUDF + " = '" + processCode + "'");
                                        if (isExists == "1")
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Process can't duplicate!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                        AutoCode(oForm);
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == CFL_BP)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_CardCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                            }

                        }

                        #endregion


                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formTypEx && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Code", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }

                        }
                        #endregion


                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }


                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Code", 0);
                    }
                    //else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    //{
                    //    objclsComman.FillCombo_Series_Custom(oForm, "", "");
                    //    DisableControls(oForm.UniqueID);
                    //}
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        //private void LoadForm(string MenuID)
        //{
        //    if (MenuID == formMenuUID)
        //    {
        //        clsVariables.boolCFLSelected = false;
        //        objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
        //        oForm = oApplication.Forms.ActiveForm;
        //        oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
        //        oForm.DataSources.UserDataSources.Item("Close").Value = "N";
        //        oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
        //        oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);

        //        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
        //        if (oMatrix.VisualRowCount == 0)
        //        {
        //            oMatrix.AddRow(1, 1);
        //        }
        //        oMatrix.CommonSetting.EnableArrowKey = true;
        //        ArrayList alCondVal = new ArrayList();
        //        ArrayList temp = new ArrayList();

        //        #region Customer Code

        //        temp = new ArrayList();
        //        temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
        //        temp.Add("CardType"); //Condition Alias             
        //        temp.Add("C"); //Condition Value
        //        temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
        //        alCondVal.Add(temp);

        //        objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDF, "2", "", "", alCondVal);
        //        objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDT, "2", "", "", alCondVal);

        //        #endregion
        //    }
        //    oForm = oApplication.Forms.ActiveForm;

        //    EnableControls(oForm.UniqueID);

        //    #region Series And DocNum

        //    try
        //    {
        //        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
        //        oEdit.String = "t";

        //        objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

        //        #region Set DocNum
        //        string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
        //        if (defaultseries == string.Empty)
        //        {
        //            oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
        //            oCombo.Select(0, BoSearchKey.psk_Index);
        //            defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
        //        }
        //        string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
        //        oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

        //        #endregion

        //    }
        //    catch { }
        //    #endregion

        //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
        //    if (oMatrix.VisualRowCount == 0)
        //    {
        //        oMatrix.AddRow(1, 1);
        //    }


        //    oItem = oForm.Items.Item("DocNum");
        //    oItem.EnableinFindMode();

        //    oItem = oForm.Items.Item("Series");
        //    oItem.EnableinAddMode();

        //    oForm.Select();
        //}

        #region LoadForm

    private void LoadForm(string MenuID)
        {

            try
            {
                if (MenuID == formTypEx)
                {
                    string FormID;
                    if (objclsComman.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }

                    objclsComman.LoadXML(MenuID, processCodeUID, string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;

                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                    //oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Dept").Specific;
                    //objclsComman.FillCombo(oCombo, "SELECT Code,Name FROM [@WEB_DEPT] ");


                    ArrayList alCondVal = new ArrayList();
                    ArrayList temp = new ArrayList();
                }


                AutoCode(oForm);

                oItem = oForm.Items.Item(processCodeUID);
                oItem.EnableinAddMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);

            }

        }


        #endregion

        private string AutoCode(SAPbouiCOM.Form oForm)
        {
            try
            {
                string Code = objclsComman.SelectRecord(" SELECT ISNULL(MAX(CAST(Code AS NUMERIC(19,0))),0) + 1  FROM [" + headerTable + "]");
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("Code", 0, Code);
                return Code;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("AutoCode:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return "";
            }
        }


        #endregion
    }
}
