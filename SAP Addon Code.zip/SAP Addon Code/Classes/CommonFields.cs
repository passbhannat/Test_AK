﻿namespace SAPAddonCode.Classes
{ 
    public static class CommonFields
    {
        public const string DocNum = "DocNum";
        public const string DocEntry = "DocEntry";
        public const string DocDate= "DocDate";
        public const string Code = "Code";
        public const string Name = "Name";
        public const string LineId = "LineId";
        public const string LineNum = "LineNum";
        public const string DistNumber = "DistNumber";
        public const string BarCode = "BarCode";

        public const string ObjType = "ObjType";
        public const string DocType = "DocType";

        /* BusinessPartnerCards */
        public const string CardCode = "CardCode";
        public const string CardName = "CardName";
            
        /* Item Master */
        public const string ItemCode = "ItemCode";
        public const string ItemName = "ItemName";

        /* Warehouse Master */
        public const string WhsCode = "WhsCode";
        public const string WhsName = "WhsName";
    }
}
 