﻿using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;


namespace SAPAddonCode.Custom_Forms
{
    class clsSalesOrder : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsCommon = new clsCommon();

        const string formTitle = "Sales Order";
        const string headerTable = "ORDR";

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        bool isItemSelected = false;
        StringBuilder sbQuery = new StringBuilder();


        #endregion
        public void ItemEvent(ref SAPbouiCOM.ItemEvent pval, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region Before_Action==true
            if (pval.Before_Action == true)
            {
                try
                {
                    if (pval.EventType == BoEventTypes.et_KEY_DOWN)
                    {
                        oForm = oApplication.Forms.Item(pval.FormUID);

                        #region Disable editing on matrix for non bom items
                        if (pval.ItemUID == "38")
                        {
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                            string treetype = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("39", pval.Row)).String;
                            string commonno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_commonno", pval.Row)).String;

                            if (treetype != "P" && commonno != string.Empty)
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion 
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
                return;
            }
            #endregion

            #region Before_Action == false
            else
            {

                if (pval.EventType == BoEventTypes.et_KEY_DOWN)
                {
                    if (pval.CharPressed == 9)
                    {
                        if (pval.ItemUID == "38")
                        {
                            #region ItemCode Tab
                            
                            if (pval.ColUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pval.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;

                                // Set Row to no color
                                oMatrix.CommonSetting.SetRowBackColor(pval.Row, -1);

                                string treeType = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("39", pval.Row)).String;
                                if (treeType == "P")
                                {
                                    

                                    string itemcode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", pval.Row)).String;
                                    string linenum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("110", pval.Row)).String;

                                    ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_commonno", pval.Row)).String = linenum;
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" SELECT T0.[Qauntity] [FatherQty],  T1.[Code] [ComponentItemCode], T1.[Quantity] [ComponentQty], T1.[Warehouse]  ");
                                    sbQuery.Append(" FROM OITT T0  INNER JOIN ITT1 T1 ON T0.[Code] = T1.[Father] ");
                                    sbQuery.Append(" WHERE T1.[Father] ='" + itemcode + "'");

                                    SAPbobsCOM.Recordset oRs = objclsCommon.returnRecord(sbQuery.ToString());
                                    string fatherQty = oRs.Fields.Item("FatherQty").Value.ToString();
                                    while (!oRs.EoF)
                                    {
                                        int lastMatrixRow = oMatrix.VisualRowCount;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", lastMatrixRow)).String = oRs.Fields.Item("ComponentItemCode").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", lastMatrixRow)).String = oRs.Fields.Item("ComponentQty").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("24", lastMatrixRow)).String = oRs.Fields.Item("Warehouse").Value.ToString();
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_commonno", lastMatrixRow)).String = linenum;
                                        try
                                        {
                                            oMatrix.CommonSetting.SetRowBackColor(lastMatrixRow, 20221504);
                                        }
                                        catch { }
                                        oRs.MoveNext();
                                    }
                                }
                            }

                            #endregion

                            #region Quantity Tab

                            else if (pval.ColUID == "11")
                            {
                                oApplication.StatusBar.SetText("Plese wait...calculation is in process", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("38").Specific;
                                string itemcode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", pval.Row)).String;
                                string commonno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_commonno", pval.Row)).String;
                                string bomquantity = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", pval.Row)).String;
                                double dblBOMQuantity = bomquantity == string.Empty ? 0 : double.Parse(bomquantity);
                                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                {
                                    if (i == pval.Row)
                                    {
                                        continue;
                                    }
                                    string rowCommonno = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_commonno", i)).String;
                                    if (rowCommonno == commonno)
                                    {
                                        string rowItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                        string rowComponentQuantity = objclsCommon.SelectRecord("SELECT Quantity FROM ITT1 WHERE Father = '" + itemcode + "' AND Code = '" + rowItemCode + "' ");
                                        double dblRowComponentQuantity = rowComponentQuantity == string.Empty ? 0 : double.Parse(rowComponentQuantity);

                                        double dblRowQuantity = dblBOMQuantity * dblRowComponentQuantity;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("11", i)).String = dblRowQuantity.ToString();
                                    }
                                }

                                oApplication.StatusBar.SetText("Process completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);

                            }

                            #endregion

                        }
                    }
                }

            }
            #endregion
        }
    }
}
