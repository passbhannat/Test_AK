using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.IO;
using System.Collections;

namespace Sales
{  
    public partial class frmBrowse : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        #region Constructor
        
        public frmBrowse()
        {
            InitializeComponent();
           
        }
        
        #endregion

        #region Load
        private void ShowDialog_Load(object sender, EventArgs e)
        {
            SetForegroundWindow(this.Handle);

            this.Visible = false;
            this.TopMost = true;
            string FileLoc = "";
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Excel Files(.xls)|*.xls|Excel Files(.xlsx)|*.xlsx| Excel Files(*.xlsm)|*.xlsm";  
            DialogResult dr = ofd.ShowDialog(); 
            if (dr == DialogResult.OK)
            {
                FileLoc = ofd.FileName;
            }
             
            this.Close();
            clsVariables.BrowsePath= FileLoc;
      
              
        }
        #endregion

    }
}