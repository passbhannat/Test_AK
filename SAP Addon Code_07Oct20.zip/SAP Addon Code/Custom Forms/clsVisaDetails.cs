﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SAPbouiCOM;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;
using System.Windows.Forms;
using System.Data;

namespace SAPAddonCode.Custom_Forms
{
    class clsVisaDetails : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.DBDataSource oDbDataSource1 = null;
        public SAPbouiCOM.DBDataSource oDbDataSource2 = null;

        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "VISADETAILS";
        const string formTypEx = "VISADETAILS";
        const string formTitle = "Visa Details";
        const string headerTable = "@VISADETAILS";
        const string rowTable1 = "@VISADETAILS1";
        const string rowTable2 = "@VISADETAILS2";
        const string rowTable3 = "@VISADETAILS3";
        const string rowTable4 = "@VISADETAILS4";
        const string rowTable5 = "@VISADETAILS5";
        const string rowTable6 = "@VISADETAILS6";

        const string objType = "RECPROD";

        const string rowTablePrimaryUDF1 = "U_SrpCode";
        const string rowTablePrimaryUDF2 = "U_ResCode";

        const string matrixUID1 = "mtx1";
        const string matrixUID2 = "mtx2";

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string mixNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MixNo", 0).ToString().Trim();
                                    if (mixNo == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Mixing No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {
                                return;
                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }

                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable1);
                            oDbDataSource2 = oForm.DataSources.DBDataSources.Item(rowTable2);

                            if (oCFLEvento.ChooseFromListUID == "CFL_MIX_OPEN")
                            {
                                string a = oDataTable.GetValue(CommonFields.U_MixNo, 0).ToString();
                                oDbDataSource.SetValue("U_MixNo", 0, oDataTable.GetValue(CommonFields.U_MixNo, 0).ToString());
                                oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue("U_FGCode", 0).ToString());
                                oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue("U_FGName", 0).ToString());
                                oDbDataSource.SetValue("U_Unit", 0, oDataTable.GetValue("U_Unit", 0).ToString());
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue("U_WhsCode", 0).ToString());

                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_FGCODE")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WhsCode")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_SCITEM")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_SrpCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_SrpName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_SrpGrp", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_SCWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_SrpWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_RES")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx2").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_ResCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResCode, 0).ToString());
                                oDbDataSource.SetValue("U_ResName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResName, 0).ToString());
                                oDbDataSource.SetValue("U_ResGrp", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResGrpCod, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_RESWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx2").Specific;
                                oMatrix.FlushToDataSource();
                                string whscode = oDataTable.GetValue(CommonFields.WhsCode, 0).ToString();
                                string itemcode = oDbDataSource.GetValue("U_ResCode", pVal.Row - 1).ToString();
                                string mixQty = oDbDataSource.GetValue("U_Qty", pVal.Row - 1).ToString();
                                double dblMixQty = mixQty == string.Empty ? 0 : double.Parse(mixQty);
                                oDbDataSource.SetValue("U_ResWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                double dblAvgCost = objclsComman.GetAverageCost(itemcode, whscode);
                                oDbDataSource.SetValue("U_PerUCost", pVal.Row - 1, dblAvgCost.ToString());
                                oDbDataSource.SetValue("U_TotalV", pVal.Row - 1, (dblMixQty * dblAvgCost).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                        }


                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formTypEx && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }

                        }
                        #endregion

                        #region F_ItemChanged

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "U_ProType")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string productionType = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ProType", 0).Trim();
                                if (productionType.ToLower() == "o")
                                {
                                    oForm.Items.Item("U_FGCode").Disable();
                                    oForm.Items.Item("U_FGBatNo").Disable();
                                }
                                else
                                {
                                    oForm.Items.Item("U_FGCode").Enable();
                                    oForm.Items.Item("U_FGBatNo").Enable();
                                }
                            }
                            else if (pVal.ItemUID == "mtx2")
                            {
                                if (pVal.ColUID == "U_Unit" || pVal.ColUID == "U_Qty")
                                {
                                    CalcTotalCost();
                                }
                            }
                        }

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.BeforeAction == true

            if (pVal.BeforeAction == true)
            {
                try
                {
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch { }
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.BeforeAction == false

            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID1, rowTable1, rowTablePrimaryUDF1);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID2, rowTable1, rowTablePrimaryUDF1);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        objclsComman.SelectRecord("DELETE FROM \"" + rowTable1 + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \""+rowTablePrimaryUDF1+"\" IS NULL ");
                        objclsComman.SelectRecord("DELETE FROM \"" + rowTable2 + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"" + rowTablePrimaryUDF2 + "\" IS NULL ");
                    }

                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        private void LoadForm(string MenuID)
        {
            try
            {
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsComman.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);
                     
                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;
                     
                    oMatrix = oForm.Items.Item("mtx2").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oMatrix = oForm.Items.Item("mtx3").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oMatrix = oForm.Items.Item("mtx4").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oMatrix = oForm.Items.Item("mtx5").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oMatrix = oForm.Items.Item("mtx6").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;
                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();

                #region Date,Series and DocNum
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocReq").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, objType, "U_DocReq", "Load");
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalcTotalCost()
        {
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = oForm.Items.Item("mtx2").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowUnit = oDbDataSource.GetValue("U_Unit", i);
                double dblRowUnit = rowUnit == string.Empty ? 0 : double.Parse(rowUnit);

                string rowQuantity = oDbDataSource.GetValue("U_Qty", i);
                double dblRowQuantity = rowQuantity == string.Empty ? 0 : double.Parse(rowQuantity);

                string rowPerUnitCost = oDbDataSource.GetValue("U_PerUCost", i);
                double dblRowPerUnitCost = rowPerUnitCost == string.Empty ? 0 : double.Parse(rowPerUnitCost);

                oDbDataSource.SetValue("U_TotalV", i, (dblRowUnit * dblRowQuantity * dblRowPerUnitCost).ToString());
            }
            oMatrix.LoadFromDataSource();
        }
    }
}
