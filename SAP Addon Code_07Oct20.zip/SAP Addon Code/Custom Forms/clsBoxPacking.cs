﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using SAPAddonCode.Extensions;
using SAPAddonCode.Classes;
using SAPbouiCOM;

namespace SAPAddonCode.Custom_Forms
{
    class clsBoxPacking : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        public SAPbouiCOM.DBDataSource oDbDataSource1 = null;

        clsCommon objclsCommon = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "BOXPACKING";
        const string formTypEx = "BOXPACKING";
        const string formTitle = "Box Packing";
        public const string headerTable = "@BOXPACKING";
        public const string rowTable = "@BOXPACKING1";
        const string objType = "BOXPACKING";

        const string matrixUID1 = "mtx1";

        public void ItemEvent(ref ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.Before_Action == true
            if (pVal.Before_Action == true)
            {
                try
                {
                    #region T_et_ITEM_PRESSED
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        #region Add Record
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                string FGItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGCode", 0).ToString().Trim();
                                if (FGItemCode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select FG Item Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string FGWhs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGWhs", 0).ToString().Trim();
                                if (FGWhs == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select FG WhsCode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string whscode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_WhsCode", 0).ToString().Trim();
                                if (whscode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Unpacked WhsCode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string totalBag = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalNum", 0).Trim();
                                double iTotalBag = totalBag == string.Empty ? 0 : int.Parse(totalBag);
                                if (iTotalBag == 0)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please enter total number of bags", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                            }
                        }
                        #endregion

                        #region Generate Bag
                        else if (pVal.ItemUID == "btGen")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string totalBag = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalNum", 0).Trim();
                            double iTotalBag = totalBag == string.Empty ? 0 : int.Parse(totalBag);
                            if (iTotalBag == 0)
                            {
                                oApplication.StatusBar.SetText("Please enter total number of bags", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            oMatrix = oForm.Items.Item(matrixUID1).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource1.Clear();
                            for (int i = 0; i < iTotalBag; i++)
                            {
                                oDbDataSource1.InsertRecord(i);
                                oDbDataSource1.SetValue("LineId", i, (i + 1).ToString());
                            }
                            oMatrix.LoadFromDataSource();

                        }
                        #endregion
                    }
                    #endregion

                    #region T_et_CHOOSE_FROM_LIST
                    else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "U_LotNo")
                        {
                            string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGCode", 0).Trim();
                            string whscode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGWhs", 0).Trim();

                            if (itemcode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Please select FG itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                            else if (whscode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Please select FG warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                            sbQuery.Length = 0;
                            sbQuery.Append(objclsCommon.GetAllBatchQuery(itemcode, whscode));
                            objclsCommon.AddChooseFromList_WithQuery(oForm, "CFL_LOTNO", "10000044", sbQuery.ToString(), "DistNumber");
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.Before_Action == false
            else if (pVal.Before_Action == false)
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }
                        oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                        oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                        if (oCFLEvento.ChooseFromListUID == "CFL_FGITEM")
                        {
                            oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE")
                        {
                            oDbDataSource.SetValue("U_FGWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_LOTNO")
                        {
                            oDbDataSource.SetValue("U_LotNo", 0, oDataTable.GetValue(CommonFields.DistNumber, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_PACKITEM")
                        {
                            oDbDataSource.SetValue("U_PackCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_PackName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            oDbDataSource.SetValue("U_PackWt", 0, oDataTable.GetValue(CommonFields.BWeight1, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE2")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                    }
                    #endregion

                    #region F_pVal.ItemChanged == true
                    if (pVal.ItemChanged == true)
                    {
                        if (pVal.ItemUID == "U_PackWt")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string weight = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PackWt", 0).Trim();
                            double dblWeight = weight == string.Empty ? 0 : double.Parse(weight);
                            double iMultipleFactor = 4;

                            oMatrix = oForm.Items.Item(matrixUID1).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                            for (int i = 0; i < oDbDataSource1.Size; i++)
                            {
                                double dblTrWt = iMultipleFactor * dblWeight;
                                double dblGrWt = double.Parse(oDbDataSource1.GetValue("U_GrWt", i));

                                oDbDataSource1.SetValue("U_TrWt", i, Convert.ToString(dblTrWt));
                                oDbDataSource1.SetValue("U_NetWt", i, Convert.ToString(dblGrWt - dblTrWt));
                            }
                            oMatrix.LoadFromDataSource();
                        }
                    }
                    #endregion  
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion
        }

        public void MenuEvent(ref MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch { }

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                else
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        CreateIT();
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm.Items.Item("btGen").Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        private void LoadForm(string MenuID)
        {
            try
            {
                #region
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;

                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oCombo = oForm.Items.Item("U_Unit").Specific;
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetUnitQuery());
                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    #region Packing ItemCode
                    List<clsCFLEntity> _clsCFLEntity = new List<clsCFLEntity>();
                    _clsCFLEntity.Add(new clsCFLEntity { });
                    _clsCFLEntity[0].Alias = "U_Pack";
                    _clsCFLEntity[0].CondVal = "Y";
                    _clsCFLEntity[0].Operation = BoConditionOperation.co_EQUAL;

                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_PACKITEM", _clsCFLEntity);
                    #endregion
                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("U_FGCode").EnableinAddMode();

                oForm.Items.Item("btGen").Visible = true;

                #region series and Date
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_PackDate").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_PackDate", "Load");

                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion
            }
            #endregion
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void CreateIT()
        {
            oForm = oApplication.Forms.ActiveForm;
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            SAPbobsCOM.StockTransfer oDoc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);
            oDoc.DocDate = DateTime.Now;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT  T0.\"U_FGCode\" \"ItemCode\" , T0.\"U_FGWhs\" \"From_WhsCode\", T0.\"U_WhsCode\" \"To_WhsCode\",T2.\"" + CommonFields.ManBtchNum + "\",     ");
                sbQuery.Append("   T0.\"U_TotalNum\" \"Quantity\",T0.\"U_LotNo\" \"LotNo\"    ");

                sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                //sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"U_FGCode\" = T2.\"" + CommonFields.ItemCode + "\" ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "' ");
                sbQuery.Append(" AND IFNULL(T0.\"U_ITEn\",'') = '' AND  T0.\"U_FGWhs\" !=  T0.\"U_WhsCode\" ");

                oRs = objclsCommon.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    return;
                }

                oDoc.FromWarehouse = oRs.Fields.Item("From_WhsCode").Value.ToString();
                int row = 0;
                while (!oRs.EoF)
                {
                    if (row > 0)
                    {
                        oDoc.Lines.Add();
                    }
                    if (row == 0)
                    {
                        oDoc.ToWarehouse = oRs.Fields.Item("To_WhsCode").Value.ToString();
                    }
                    oDoc.Lines.ItemCode = oRs.Fields.Item("ItemCode").Value.ToString();
                    oDoc.Lines.WarehouseCode = oRs.Fields.Item("To_WhsCode").Value.ToString();

                    double dblQuantity = oRs.Fields.Item(CommonFields.Quantity).Value.ToString() == string.Empty ? 0 : double.Parse(oRs.Fields.Item(CommonFields.Quantity).Value.ToString());
                    oDoc.Lines.Quantity = dblQuantity;
                    if (oRs.Fields.Item(CommonFields.ManBtchNum).Value.ToString() == "Y")
                    {
                        oDoc.Lines.BatchNumbers.BatchNumber = oRs.Fields.Item("LotNo").Value.ToString();
                        oDoc.Lines.BatchNumbers.Quantity = dblQuantity;
                        oDoc.Lines.BatchNumbers.Add();
                    }
                    oDoc.Lines.SetCurrentLine(row);
                    oRs.MoveNext();
                    row++;
                }

                int retVal = oDoc.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Create Inventory Transfer Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    sbQuery.Length = 0;
                    sbQuery.Append("UPDATE T0 SET \"U_ITEn\" = '" + newDocEntry + "',\"U_ITNo\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "' ");
                    objclsCommon.SelectRecord(sbQuery.ToString());
                    oApplication.StatusBar.SetText("Inventory Order Transfer " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    // objclsComman.RefreshRecord();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create IT catch exception :" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                //objclsComman.ReleaseObject(oRs);
            }
        }

    }
}
