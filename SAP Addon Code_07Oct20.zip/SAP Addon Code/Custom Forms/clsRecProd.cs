﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SAPbouiCOM;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;
using System.Windows.Forms;
using System.Data;

namespace SAPAddonCode.Custom_Forms
{
    class clsRecProd : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.DBDataSource oDbDataSource1 = null;
        SAPbouiCOM.DBDataSource oDbDataSource2 = null;

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "RECPROD";
        const string formTypEx = "RECPROD";
        const string formTitle = "Reciept From Production";
        const string headerTable = "@RECPROD";
        const string rowTable1 = "@RECPROD1";
        const string rowTable2 = "@RECPROD2";
        const string objType = "RECPROD";
        const string rowTablePrimaryUDF1 = "U_SrpCode";
        const string rowTablePrimaryUDF2 = "U_ResCode";
        const string matrixUID1 = "mtx1";
        const string matrixUID2 = "mtx2";

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region Add Record
                            if (pVal.ItemUID == "1")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string mixNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MixNo", 0).ToString().Trim();
                                    if (mixNo == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Mixing No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    string fgBatchNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGBatNo", 0).ToString().Trim();
                                    if (fgBatchNo == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please enter batch no", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    string quantity = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_RecQty", 0).ToString().Trim();
                                    double dblQuantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                                    if (dblQuantity == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please enter receipt quantity", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }

                                    #region Scrap Matrix validation
                                    oMatrix = oForm.Items.Item(matrixUID1).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable1);
                                    for (int i = 0; i < oDbDataSource1.Size; i++)
                                    {
                                        string itemcode = oDbDataSource1.GetValue("U_SrpCode", i).Trim();
                                        if (itemcode != string.Empty)
                                        {
                                            if (oDbDataSource1.GetValue("U_SrpWhs", i).Trim() == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Scrap Details Tab: Please select scrap warehouse for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            string scrapQuantity = oDbDataSource1.GetValue("U_RecQty", i).Trim();
                                            double dblScrapQuantity = scrapQuantity == string.Empty ? 0 : double.Parse(scrapQuantity);
                                            if (dblScrapQuantity == 0)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Scrap Details Tab: Please enter receipt quantity for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            if (oDbDataSource1.GetValue("U_BatchNo", i).Trim() == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Scrap Details Tab: Please enter batch no for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                        }
                                    }
                                    #endregion

                                    #region Resource Matrix validation
                                    oMatrix = oForm.Items.Item(matrixUID2).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource2 = oForm.DataSources.DBDataSources.Item(rowTable2);
                                    for (int i = 0; i < oDbDataSource2.Size; i++)
                                    {
                                        string itemcode = oDbDataSource2.GetValue("U_ResCode", i).Trim();
                                        if (itemcode != string.Empty)
                                        {
                                            if (oDbDataSource2.GetValue("U_ResWhs", i).Trim() == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Resource Details Tab: Please select resource warehouse for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                            string resQuantity = oDbDataSource2.GetValue("U_Qty", i).Trim();
                                            double dbResQuantity = resQuantity == string.Empty ? 0 : double.Parse(resQuantity);
                                            if (dbResQuantity == 0)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Resource Details Tab: Please enter quantity for Row: " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }

                                        }
                                    }
                                    #endregion
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Generate
                            else if (pVal.ItemUID == "btGenPO")
                            {
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                int i = oApplication.MessageBox("Do you really want to continue?", 2, "Yes", "No", "");
                                if (i == 1)
                                {
                                    bool isRecordAdded = false;
                                    if (Create_IssueFromProduction(oForm.UniqueID) == true)
                                    {
                                        isRecordAdded = true;
                                    }
                                    if (Create_ReceiptFromProduction() == true)
                                    {
                                        isRecordAdded = true;
                                    }
                                    if (isRecordAdded == true)
                                    {
                                        objclsCommon.RefreshRecord();
                                    }
                                }
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {
                                return;
                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }

                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (pVal.ItemUID == "U_MixNo")
                            {
                                string productionType = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ProType", 0).Trim();
                                oEdit = oForm.Items.Item(pVal.ItemUID).Specific;
                                if (productionType == "O")
                                {
                                    oEdit.ChooseFromListUID = "CFL_MIX_OPEN";
                                }
                                else
                                {
                                    oEdit.ChooseFromListUID = "CFL_MIX_RING";
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable1);
                            oDbDataSource2 = oForm.DataSources.DBDataSources.Item(rowTable2);

                            if (oCFLEvento.ChooseFromListUID == "CFL_MIX_OPEN")
                            {
                                oDbDataSource.SetValue("U_MixNo", 0, oDataTable.GetValue(CommonFields.U_MixNo, 0).ToString());
                                oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue("U_FGCode", 0).ToString());
                                oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue("U_FGName", 0).ToString());
                                oDbDataSource.SetValue("U_Unit", 0, oDataTable.GetValue("U_Unit", 0).ToString());
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue("U_WhsCode", 0).ToString());
                                oDbDataSource.SetValue("U_FGBatNo", 0, oDataTable.GetValue("U_FGLNo", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_MIX_RING")
                            {
                                oDbDataSource.SetValue("U_MixNo", 0, oDataTable.GetValue(CommonFields.U_MixNo, 0).ToString());
                                oDbDataSource.SetValue("U_Unit", 0, oDataTable.GetValue("U_Unit", 0).ToString());
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue("U_WhsCode", 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_FGCODE")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WhsCode")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_SCITEM")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_SrpCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_SrpName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_SrpGrp", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_SCWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable1);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_SrpWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_RES")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx2").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_ResCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResCode, 0).ToString());
                                oDbDataSource.SetValue("U_ResName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResName, 0).ToString());
                                oDbDataSource.SetValue("U_ResGrp", pVal.Row - 1, oDataTable.GetValue(CommonFields.ResGrpCod, 0).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_RESWHS")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx2").Specific;
                                oMatrix.FlushToDataSource();
                                string whscode = oDataTable.GetValue(CommonFields.WhsCode, 0).ToString();
                                string itemcode = oDbDataSource.GetValue("U_ResCode", pVal.Row - 1).ToString();
                                string mixQty = oDbDataSource.GetValue("U_Qty", pVal.Row - 1).ToString();
                                double dblMixQty = mixQty == string.Empty ? 0 : double.Parse(mixQty);
                                oDbDataSource.SetValue("U_ResWhs", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                double dblAvgCost = objclsCommon.GetAverageCost(itemcode, whscode);
                                oDbDataSource.SetValue("U_PerUCost", pVal.Row - 1, dblAvgCost.ToString());
                                oDbDataSource.SetValue("U_TotalV", pVal.Row - 1, (dblMixQty * dblAvgCost).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                        }


                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formTypEx && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }

                        }
                        #endregion

                        #region F_ItemChanged

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "U_ProType")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                EnableDisable_ProductionType(pVal.FormUID);
                            }
                            else if (pVal.ItemUID == "mtx2")
                            {
                                if (pVal.ColUID == "U_Unit" || pVal.ColUID == "U_Qty")
                                {
                                    CalcTotalCost();
                                }
                            }
                        }

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.BeforeAction == true

            if (pVal.BeforeAction == true)
            {
                try
                {
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch { }
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.BeforeAction == false

            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        SAPbouiCOM.Folder oFolder = oForm.Items.Item("fld1").Specific;
                        if (oFolder.Selected == true)
                        {
                            AddRow(matrixUID1, rowTable1, rowTablePrimaryUDF1);
                        }
                        else
                        {
                            AddRow(matrixUID2, rowTable2, rowTablePrimaryUDF2);
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        SAPbouiCOM.Folder oFolder = oForm.Items.Item("fld1").Specific;
                        if (oFolder.Selected == true)
                        {
                            DeleteRow(matrixUID1, rowTable1, rowTablePrimaryUDF1);
                        }
                        else
                        {
                            DeleteRow(matrixUID2, rowTable2, rowTablePrimaryUDF2);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        objclsCommon.SelectRecord("DELETE FROM \"" + rowTable1 + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"" + rowTablePrimaryUDF1 + "\" IS NULL ");
                        objclsCommon.SelectRecord("DELETE FROM \"" + rowTable2 + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"" + rowTablePrimaryUDF2 + "\" IS NULL ");
                        Create_ProdcutionOrder_Special();
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        EnableDisable_ProductionType(BusinessObjectInfo.FormUID);
                        oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        private void LoadForm(string MenuID)
        {
            try
            {
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(MenuID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);

                    oCombo = oForm.Items.Item("U_PackType").Specific;
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetPackingTypeQuery());

                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_SrpGrp", 1);
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetItemGroupQuery());

                    oMatrix = oForm.Items.Item("mtx2").Specific;
                    oMatrix.AddRow(1, 1);
                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_ResGrp", 1);
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetResourceGroupQuery());

                    #region Scrap ItemCode
                    List<clsCFLEntity> _clsCFLEntity = new List<Classes.clsCFLEntity>();
                    _clsCFLEntity.Add(new clsCFLEntity { });
                    _clsCFLEntity[0].Alias = "U_Scrap";
                    _clsCFLEntity[0].CondVal = "Y";
                    _clsCFLEntity[0].Operation = BoConditionOperation.co_EQUAL;

                    objclsCommon.AddChooseFromList_WithList(oForm, "CFL_SCITEM", _clsCFLEntity);
                    #endregion
                }
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ProType", 0, "O");
                //oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("U_ProType").EnableinAddMode();
                oForm.Items.Item("U_MixNo").EnableinAddMode();

                oForm.Items.Item("U_FGCode").Disable();
                oForm.Items.Item("U_FGBatNo").Disable();


                #region Date,Series and DocNum
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_RecDate").Specific;
                oEdit.String = "t";

                objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_RecDate", "Load");
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalcTotalCost()
        {
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = oForm.Items.Item("mtx2").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable2);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowUnit = oDbDataSource.GetValue("U_Unit", i);
                double dblRowUnit = rowUnit == string.Empty ? 0 : double.Parse(rowUnit);

                string rowQuantity = oDbDataSource.GetValue("U_Qty", i);
                double dblRowQuantity = rowQuantity == string.Empty ? 0 : double.Parse(rowQuantity);

                string rowPerUnitCost = oDbDataSource.GetValue("U_PerUCost", i);
                double dblRowPerUnitCost = rowPerUnitCost == string.Empty ? 0 : double.Parse(rowPerUnitCost);

                oDbDataSource.SetValue("U_TotalV", i, (dblRowUnit * dblRowQuantity * dblRowPerUnitCost).ToString());
            }
            oMatrix.LoadFromDataSource();
        }

        private void Create_ProdcutionOrder_Special()
        {
            oForm = oApplication.Forms.ActiveForm;
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            SAPbobsCOM.Recordset oRs = null;
            string lineId = string.Empty;
            int childRow = 0;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ");
            sbQuery.Append(" T0.\"U_FGCode\", T0.\"U_RecDate\", T0.\"U_RecQty\", T0.\"U_WhsCode\", T0.\"U_ProType\", T0.\"U_MixNo\" ,  ");
            sbQuery.Append(" (SELECT SUM(\"U_RecQty\") FROM \"" + rowTable1 + "\" A WHERE A.\"DocEntry\" = T0.\"DocEntry\" ) AS \"ScrapQty\" ");

            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
            sbQuery.Append(" AND IFNULL(T0.\"U_POEn\",'') = '' ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            if (oRs.RecordCount == 0)
            {
                return;
            }

            SAPbobsCOM.ProductionOrders oDocument = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

            while (!oRs.EoF)
            {
                #region Header

                oDocument.StartDate = DateTime.Parse(oRs.Fields.Item("U_RecDate").Value.ToString());
                oDocument.DueDate = DateTime.Parse(oRs.Fields.Item("U_RecDate").Value.ToString());
                oDocument.PostingDate = DateTime.Parse(oRs.Fields.Item("U_RecDate").Value.ToString());

                oDocument.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotSpecial;
                oDocument.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                oDocument.ItemNo = oRs.Fields.Item("U_FGCode").Value;
                oDocument.Warehouse = oRs.Fields.Item("U_WhsCode").Value;
                oDocument.PlannedQuantity = oRs.Fields.Item("U_RecQty").Value;

                #endregion

                string fgQty = oRs.Fields.Item("U_RecQty").Value.ToString();
                double dblFgQty = fgQty == string.Empty ? 0 : double.Parse(fgQty);


                string scrapQty = oRs.Fields.Item("ScrapQty").Value.ToString();
                double dblScrapQty = scrapQty == string.Empty ? 0 : double.Parse(scrapQty);

                double dblTotalProduction = dblFgQty + dblScrapQty;

                #region RM Items

                string productionType = oRs.Fields.Item("U_ProType").Value;
                string mixNo = oRs.Fields.Item("U_MixNo").Value;

                sbQuery = new StringBuilder();
                if (productionType == "O")
                {
                    sbQuery.Append(" SELECT ");
                    sbQuery.Append(" T0.\"U_RMCode\", T0.\"U_MixQty\", T0.\"U_MixPer\", T0.\"U_WhsCode\"  ");
                    sbQuery.Append(" FROM \"" + clsOpenEnd.rowTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN \"" + clsOpenEnd.headerTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\"   ");
                    sbQuery.Append(" WHERE T1.\"U_MixNo\" = '" + mixNo + "'  ");
                    sbQuery.Append(" AND IFNULL(T0.\"U_RMCode\",'') != '' ");
                }
                else
                {
                    sbQuery.Append(" SELECT ");
                    sbQuery.Append(" T0.\"U_RMCode\", T0.\"U_MixQty\", T0.\"U_MixPer\", T0.\"U_WhsCode\"  ");
                    sbQuery.Append(" FROM \"" + clsRingSpun.rowTable + "\" T0 ");
                    sbQuery.Append(" INNER JOIN \"" + clsRingSpun.headerTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\"   ");
                    sbQuery.Append(" WHERE T1.\"U_MixNo\" = '" + mixNo + "'  ");
                    sbQuery.Append(" AND IFNULL(T0.\"U_RMCode\",'') != '' ");
                }
                SAPbobsCOM.Recordset oRsRM = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRsRM.EoF)
                {
                    oDocument.Lines.SetCurrentLine(childRow);
                    oDocument.Lines.ItemNo = oRsRM.Fields.Item("U_RMCode").Value.ToString();
                    oDocument.Lines.Warehouse = oRsRM.Fields.Item("U_WhsCode").Value.ToString();
                    oDocument.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                    double dblMixPer = oRsRM.Fields.Item("U_MixPer").Value;
                    double dblPlannedQty = dblTotalProduction * dblMixPer / 100;
                    oDocument.Lines.PlannedQuantity = dblPlannedQty;
                    oDocument.Lines.Add();
                    childRow++;
                    oRsRM.MoveNext();
                }
                #endregion


                #region Scrap Items

                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT ");
                sbQuery.Append(" T0.\"U_SrpCode\", T0.\"U_SrpWhs\", T0.\"U_RecQty\"  ");
                sbQuery.Append(" FROM \"" + rowTable1 + "\" T0 ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
                sbQuery.Append(" AND IFNULL(T0.\"" + rowTablePrimaryUDF1 + "\",'') != '' ");
                SAPbobsCOM.Recordset oRsScrap = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRsScrap.EoF)
                {
                    oDocument.Lines.SetCurrentLine(childRow);
                    oDocument.Lines.ItemNo = oRsScrap.Fields.Item("U_SrpCode").Value.ToString();
                    oDocument.Lines.Warehouse = oRsScrap.Fields.Item("U_SrpWhs").Value.ToString();
                    oDocument.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                    oDocument.Lines.PlannedQuantity = (-1) * oRsScrap.Fields.Item("U_RecQty").Value;
                    oDocument.Lines.Add();
                    childRow++;
                    oRsScrap.MoveNext();
                }
                #endregion

                #region Resouce Items

                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT ");
                sbQuery.Append(" T0.\"U_ResCode\", T0.\"U_ResWhs\", T0.\"U_Qty\"  ");
                sbQuery.Append(" FROM \"" + rowTable2 + "\" T0 ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
                sbQuery.Append(" AND IFNULL(T0.\"" + rowTablePrimaryUDF2 + "\",'') != '' ");
                SAPbobsCOM.Recordset oRsResource = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRsResource.EoF)
                {
                    oDocument.Lines.SetCurrentLine(childRow);
                    oDocument.Lines.ItemType = SAPbobsCOM.ProductionItemType.pit_Resource;
                    oDocument.Lines.ItemNo = oRsResource.Fields.Item("U_ResCode").Value.ToString();
                    oDocument.Lines.Warehouse = oRsResource.Fields.Item("U_ResWhs").Value.ToString();
                    oDocument.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                    oDocument.Lines.PlannedQuantity = oRsResource.Fields.Item("U_Qty").Value;
                    oDocument.Lines.Add();
                    childRow++;
                    oRsResource.MoveNext();
                }
                #endregion

                oRs.MoveNext();
            }
            int retVal = oDocument.Add();
            if (retVal != 0)
            {
                oApplication.StatusBar.SetText("Production Order Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            else
            {
                string PODocEntry = oCompany.GetNewObjectKey();
                objclsCommon.ConvertProductionOrder_To_Release(Int32.Parse(PODocEntry));
                string PODocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OWOR WHERE \"DocEntry\" = '" + PODocEntry + "'");
                objclsCommon.SelectRecord("UPDATE T0 SET \"U_POEn\" = '" + PODocEntry + "',\"U_PONo\" = '" + PODocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "'  ");
                oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
        }

        private bool Create_IssueFromProduction(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            string poDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_POEn", 0).Trim();

            SAPbobsCOM.Recordset oRs = null;
            string lineId = string.Empty;
            int childRow = 0;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ");
            sbQuery.Append(" T0.\"U_FGCode\", T0.\"U_RecDate\", T0.\"U_RecQty\", T0.\"U_WhsCode\", T0.\"U_ProType\", T0.\"U_MixNo\" , T0.\"U_POEn\"  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
            sbQuery.Append(" AND IFNULL(T0.\"U_IssEn\",'') = '' ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            if (oRs.RecordCount == 0)
            {
                return true;
            }
            SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit);
            try
            {
                while (!oRs.EoF)
                {
                    #region Header

                    oDocument.DocDate = DateTime.Parse(oRs.Fields.Item("U_RecDate").Value.ToString());

                    #endregion

                    string productionType = oRs.Fields.Item("U_ProType").Value;
                    string mixNo = oRs.Fields.Item("U_MixNo").Value;
                    string poEntry = oRs.Fields.Item("U_POEn").Value.ToString();

                    sbQuery = new StringBuilder();

                    if (productionType == "O")
                    {
                        sbQuery.Append(" SELECT T0.\"ItemCode\",T0.\"PlannedQty\",T0.\"LineNum\",T1.\"ManBtchNum\" ");
                        sbQuery.Append(" ,T4.\"U_BatchNo\" ");
                        sbQuery.Append(" FROM WOR1 T0 ");
                        sbQuery.Append(" INNER JOIN OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                        sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T2 ON T0.\"DocEntry\" = T2.\"U_POEn\" ");
                        sbQuery.Append(" INNER JOIN \"" + clsOpenEnd.headerTable + "\" T3 ON T2.\"U_MixNo\" = T3.\"U_MixNo\" ");
                        sbQuery.Append(" INNER JOIN \"" + clsOpenEnd.rowTable + "\" T4 ON T3.\"DocEntry\" = T4.\"DocEntry\"  AND T0.\"ItemCode\" = T4.\"U_RMCode\" ");
                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + poEntry + "' ");
                    }
                    else
                    {
                        sbQuery.Append(" SELECT T0.\"ItemCode\",T0.\"PlannedQty\",T0.\"LineNum\",T1.\"ManBtchNum\" ");
                        sbQuery.Append(" ,T4.\"U_BatchNo\" ");
                        sbQuery.Append(" FROM WOR1 T0 ");
                        sbQuery.Append(" INNER JOIN OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                        sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T2 ON T0.\"DocEntry\" = T2.\"U_POEn\" ");
                        sbQuery.Append(" INNER JOIN \"" + clsRingSpun.headerTable + "\" T3 ON T2.\"U_MixNo\" = T3.\"U_MixNo\" ");
                        sbQuery.Append(" INNER JOIN \"" + clsRingSpun.rowTable + "\" T4 ON T3.\"DocEntry\" = T4.\"DocEntry\"  AND T0.\"ItemCode\" = T4.\"U_RMCode\" ");
                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + poEntry + "' ");
                    }
                    SAPbobsCOM.Recordset oRsItem = objclsCommon.returnRecord(sbQuery.ToString());
                    while (!oRsItem.EoF)
                    {
                        if (childRow > 0)
                        {
                            oDocument.Lines.Add();
                        }
                        oDocument.Lines.SetCurrentLine(childRow);
                        oDocument.Lines.BaseEntry = Int32.Parse(poDocEntry);
                        oDocument.Lines.BaseType = 202;
                        oDocument.Lines.BaseLine = int.Parse(oRsItem.Fields.Item("LineNum").Value.ToString());
                        //oDocument.Lines.Quantity = oRsItem.Fields.Item("PlannedQty").Value;

                        //oDocument.Lines.ItemCode = oRsItem.Fields.Item("U_RMCode").Value.ToString();
                        //oDocument.Lines.WarehouseCode = oRsItem.Fields.Item("U_WhsCode").Value.ToString();
                        string itemcode = oRsItem.Fields.Item("ItemCode").Value.ToString();
                        string batchDocEntry = oRsItem.Fields.Item("U_BatchNo").Value.ToString();
                        string manBatch = oRsItem.Fields.Item("ManBtchNum").Value.ToString(); // objclsCommon.GetIsItemManageByBatchQuery(itemcode);
                                                                                              // manBatch = objclsCommon.SelectRecord(manBatch);
                        double plannedQty = double.Parse(oRsItem.Fields.Item("PlannedQty").Value.ToString());
                        if (manBatch == "Y")
                        {
                            double dblRequiredQty = plannedQty;
                            sbQuery.Length = 0;
                            sbQuery.Append(" SELECT \"U_BatchNo\", \"U_Qty\" ");
                            sbQuery.Append(" FROM \"" + clsOpenEndBatch.rowTable + "\" T0 ");
                            sbQuery.Append(" WHERE \"DocEntry\" = '" + batchDocEntry + "' ");
                            sbQuery.Append(" AND \"U_Qty\" > 0  ");
                            SAPbobsCOM.Recordset oRsBatch = objclsCommon.returnRecord(sbQuery.ToString());
                            int batchRow = 0;
                            while (!oRsBatch.EoF)
                            {
                                if (dblRequiredQty == 0)
                                {
                                    oRsBatch.MoveNext();
                                    continue;
                                }
                                double dblBatchQuantity = double.Parse(oRsBatch.Fields.Item("U_Qty").Value.ToString());
                                if (dblBatchQuantity > dblRequiredQty)
                                {
                                    dblBatchQuantity = dblRequiredQty;
                                }
                                if (batchRow > 0)
                                {
                                    oDocument.Lines.BatchNumbers.Add();
                                }
                                oDocument.Lines.BatchNumbers.InternalSerialNumber = oRsBatch.Fields.Item("U_BatchNo").Value.ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                                oDocument.Lines.BatchNumbers.BatchNumber = oRsBatch.Fields.Item("U_BatchNo").Value.ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                                oDocument.Lines.BatchNumbers.Quantity = dblBatchQuantity;
                                batchRow++;

                                dblRequiredQty = dblRequiredQty - dblBatchQuantity;
                                oRsBatch.MoveNext();
                            }
                        }

                        childRow++;
                        oRsItem.MoveNext();
                    }


                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT T0.\"ItemCode\",T0.\"PlannedQty\",T0.\"LineNum\"  ");
                    sbQuery.Append(" FROM WOR1 T0 ");
                    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + poEntry + "' AND \"ItemType\" = '290 '");

                    SAPbobsCOM.Recordset oRsResource = objclsCommon.returnRecord(sbQuery.ToString());
                    if (oRsResource.RecordCount > 0)
                    {
                        if (childRow > 0)
                        {
                            oDocument.Lines.Add();
                        }
                        oDocument.Lines.SetCurrentLine(childRow);
                        oDocument.Lines.BaseEntry = Int32.Parse(poDocEntry);
                        oDocument.Lines.BaseType = 202;
                        oDocument.Lines.BaseLine = int.Parse(oRsResource.Fields.Item("LineNum").Value.ToString());
                    }

                    oRs.MoveNext();
                }
                int retVal = oDocument.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Issue For Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return false;
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OIGE WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    objclsCommon.SelectRecord("UPDATE T0 SET \"U_IssEn\" = '" + newDocEntry + "',\"U_IssNo\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "'  ");
                    oApplication.StatusBar.SetText("Issue For Production No " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    return true;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Issue For Production Error: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
        }

        private bool Create_ReceiptFromProduction()
        {
            oForm = oApplication.Forms.ActiveForm;
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            string poDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_POEn", 0).Trim();

            SAPbobsCOM.Recordset oRs = null;
            string lineId = string.Empty;
            int childRow = 0;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ");
            sbQuery.Append(" T0.\"U_FGCode\", T0.\"U_RecDate\", T0.\"U_RecQty\", T0.\"U_WhsCode\",  ");
            sbQuery.Append(" T0.\"U_FGBatNo\"  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
            sbQuery.Append(" AND IFNULL(T0.\"U_RecEn\",'') = '' ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            if (oRs.RecordCount == 0)
            {
                return true;
            }
            SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);

            while (!oRs.EoF)
            {
                #region Header

                oDocument.DocDate = DateTime.Parse(oRs.Fields.Item("U_RecDate").Value.ToString());

                #endregion

                #region FG Item

                oDocument.Lines.BaseType = 202;
                oDocument.Lines.BaseEntry = Int32.Parse(poDocEntry);
                oDocument.Lines.Quantity = double.Parse(oRs.Fields.Item("U_RecQty").Value.ToString());
                oDocument.Lines.WarehouseCode = oRs.Fields.Item("U_WhsCode").Value.ToString();
                oDocument.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntComplete;
                string itemcode = oRs.Fields.Item("U_FGCode").Value.ToString();
                string manBatch = objclsCommon.GetIsItemManageByBatchQuery(itemcode);
                manBatch = objclsCommon.SelectRecord(manBatch);
                if (manBatch == "Y")
                {
                    oDocument.Lines.BatchNumbers.InternalSerialNumber = oRs.Fields.Item("U_FGBatNo").Value.ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                    oDocument.Lines.BatchNumbers.BatchNumber = oRs.Fields.Item("U_FGBatNo").Value.ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                    oDocument.Lines.BatchNumbers.Quantity = double.Parse(oRs.Fields.Item("U_RecQty").Value.ToString());
                    oDocument.Lines.BatchNumbers.Add();
                }
                oDocument.Lines.SetCurrentLine(childRow);
                childRow++;

                #endregion

                #region Scrap Items

                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT ");
                sbQuery.Append(" T0.\"LineNum\",T3.\"U_BatchNo\", T0.\"PlannedQty\" ");
                sbQuery.Append(" FROM WOR1 T0 ");
                sbQuery.Append(" INNER JOIN OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T2 ON T0.\"DocEntry\" = T2.\"U_POEn\" ");
                sbQuery.Append(" INNER JOIN \"" + rowTable1 + "\" T3 ON T2.\"DocEntry\" = T3.\"DocEntry\" ");

                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + poDocEntry + "'  ");
                sbQuery.Append(" AND T0.\"PlannedQty\" < 0 ");
                SAPbobsCOM.Recordset oRsScrap = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRsScrap.EoF)
                {
                    if (childRow > 0)
                    {
                        oDocument.Lines.Add();
                    }
                    oDocument.Lines.SetCurrentLine(childRow);
                    oDocument.Lines.BaseType = 202;
                    oDocument.Lines.BaseLine = int.Parse(oRsScrap.Fields.Item("LineNum").Value.ToString());
                    oDocument.Lines.BaseEntry = Int32.Parse(poDocEntry);
                    if (manBatch == "Y")
                    {
                        oDocument.Lines.BatchNumbers.InternalSerialNumber = oRsScrap.Fields.Item("U_BatchNo").Value.ToString();
                        oDocument.Lines.BatchNumbers.BatchNumber = oRsScrap.Fields.Item("U_BatchNo").Value.ToString();
                        double quantity = double.Parse(oRsScrap.Fields.Item("PlannedQty").Value.ToString());
                        oDocument.Lines.BatchNumbers.Quantity = (-1) * quantity;
                        oDocument.Lines.BatchNumbers.Add();
                    }
                    childRow++;
                    oRsScrap.MoveNext();
                }
                #endregion

                oRs.MoveNext();
            }
            int retVal = oDocument.Add();
            if (retVal != 0)
            {
                oApplication.StatusBar.SetText("Receipt From Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
            else
            {
                string newDocEntry = oCompany.GetNewObjectKey();
                string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + newDocEntry + "'");
                objclsCommon.SelectRecord("UPDATE T0 SET \"U_RecEn\" = '" + newDocEntry + "',\"U_RecNo\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "'  ");
                oApplication.StatusBar.SetText("Receipt From Production No " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                return true;
            }
        }

        private void EnableDisable_ProductionType(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            string productionType = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ProType", 0).Trim();
            if (productionType.ToLower() == "o")
            {
                oForm.Items.Item("U_FGCode").Disable();
                oForm.Items.Item("U_FGBatNo").Disable();
            }
            else
            {
                oForm.Items.Item("U_FGCode").Enable();
                oForm.Items.Item("U_FGBatNo").Enable();
            }
        }

    }
}
