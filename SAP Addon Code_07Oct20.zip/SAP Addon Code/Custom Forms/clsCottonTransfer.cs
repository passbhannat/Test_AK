﻿using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAPAddonCode.Custom_Forms
{
    class clsCottonTransfer : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Form oForm;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsCommon = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();

        const string formMenuUId = "COTTONTRANSFER";
        const string formTypEx = "COTTONTRANSFER";
        const string formTitle = "Cotton Transfer";
        const string headerTable = "@COTTONTRANSFER";
        const string rowTable = "@COTTONTRANSFER1";
        const string objType = "COTTONTRANSFER";

        public void ItemEvent(ref ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.Before_Action == true
            if (pVal.Before_Action == true)
            {
                try
                {
                    #region T_et_ITEM_PRESSED
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        #region Add Record
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                string ItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).ToString().Trim();
                                if (ItemCode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Item Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                            }
                        }
                        #endregion
                    }
                    #endregion

                    #region T_et_CHOOSE_FROM_LIST
                    else if (pVal.EventType == BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "U_LotNo")
                        {
                            string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).Trim();
                            string whscode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrWhs", 0).Trim();
                            if (itemcode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                            else if (whscode == string.Empty)
                            {
                                oApplication.StatusBar.SetText("Please select From warehouse", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                BubbleEvent = false;
                                return;
                            }
                            sbQuery.Length = 0;
                            sbQuery.Append(objclsCommon.GetAllBatchQuery(itemcode, whscode));
                            objclsCommon.AddChooseFromList_WithQuery(oForm, "CFL_LOTNO", "10000044", sbQuery.ToString(), "DistNumber");
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.Before_Action == false
            else
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }
                        if (oCFLEvento.ChooseFromListUID == "CFL_ITEMCODE")
                        {

                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_ItemCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_ItemName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());

                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_FrWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE2")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_ToWhs", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }

            }
            #endregion
        }

        public void MenuEvent(ref MenuEvent pval, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pval.BeforeAction == true)
                {
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch { }
                    if (pval.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            BubbleEvent = false;
                        }
                    }
                    else if (pval.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                else if (pval.MenuUID == formMenuUId || pval.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                {
                    LoadForm(pval.MenuUID);
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + "Menu Event :" + ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        public void LoadForm(string MenuID)
        {
            try
            {
                #region MenuID is formMenuUId
                if (MenuID == formMenuUId)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;

                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oCombo = oForm.Items.Item("U_Unit").Specific;
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetUnitQuery());

                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                }
                #endregion

                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                    oEdit.String = "t";

                    objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_DocDate", "Load");
                   
                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion
                }
                catch { }

                #endregion
            }
            catch { }
        }
      
    }
}
