using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;

namespace SAPAddonCode
{
    class clsOpenEnd : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsCommon = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "OPENEND";
        const string formTypEx = "OPENEND";
        const string formTitle = "Open End Formulation";
        public const string headerTable = "@OPENEND";
        public const string rowTable = "@OPENEND1";
        public const string objType = "OPENEND";

        // string CFL_BP = nameof(CFL_BP);
        string CFL_BP = "CFL_BP";
        const string processCodeUDF = "U_PrcCode";
        const string processCodeUID = "PrcCode";

        const string matrix1UID = "mtx1";
        const string matrix1PrimaryUDF = "U_RMCode";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string fgItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGCode", 0).ToString().Trim();
                                    if (fgItemCode == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select FG Item Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    string mixNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MixNo", 0).ToString().Trim();
                                    if (mixNo == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please enter Mixing Number", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    string fgLotNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FGLNo", 0).ToString().Trim();
                                    if (fgLotNo == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please enter FG Lot Number", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    string totalMixPer = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotMPer", 0).ToString().Trim();
                                    double dblTotalMixPer = totalMixPer == string.Empty ? 0 : double.Parse(totalMixPer);
                                    if (dblTotalMixPer != 100)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Total Mix percent should be 100", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = oForm.Items.Item(matrix1UID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        string itemcode = oDbDataSource.GetValue("U_RMCode", i);
                                        if (itemcode != string.Empty)
                                        {
                                            string whscode = oDbDataSource.GetValue("U_WhsCode", i);
                                            if (whscode == string.Empty)
                                            {
                                                BubbleEvent = false;
                                                oApplication.StatusBar.SetText("Please select warehouse at Row : " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }
                                        }
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {
                                return;
                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }

                        #endregion

                        #region T_et_MATRIX_LINK_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == matrix1UID)
                            {
                                if (pVal.ColUID == "U_BatchNo")
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    if (!(oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_VIEW_MODE))
                                    {
                                        oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                        return;
                                    }
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                    string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();

                                    clsVariables.BaseFormUID = oForm.UniqueID;
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    string lineId = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(CommonFields.LineId, pVal.Row - 1).Trim();
                                    string batchDocEntry = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(pVal.ColUID, pVal.Row - 1).Trim();
                                    string itemcode = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_RMCode", pVal.Row - 1).Trim();
                                    string itemname = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_RMName", pVal.Row - 1).Trim();
                                    string qty = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_MixQty", pVal.Row - 1).Trim();
                                    string whscode = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_WhsCode", pVal.Row - 1).Trim();

                                    batchDocEntry = batchDocEntry == string.Empty ? "0" : batchDocEntry;
                                    //string qcDocEntry = objclsComman.SelectRecord("SELECT \"DocEntry\" FROM \"" + clsWeighingScaleQCParameter.headerTable + "\" WHERE \"U_BaseEn\" = '" + docEntry + "' AND  \"" + clsWeighingScaleQCParameter.baseLineUDF + "\" = '" + lineId + "'");
                                    clsOpenEndBatch obj = new clsOpenEndBatch();
                                    obj.LoadForm(clsOpenEndBatch.formTypEx);
                                    oForm = oApplication.Forms.ActiveForm;
                                    if (batchDocEntry != "0")
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                                        oEdit.String = batchDocEntry;
                                        oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    }
                                    else
                                    {
                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseEn", 0, docEntry);
                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseLine", 0, lineId);

                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseIC", 0, itemcode);
                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseIN", 0, itemname);
                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseQty", 0, qty);
                                        oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseType", 0, objType);

                                        string itemCode = string.Empty;
                                        sbQuery = new StringBuilder();
                                        sbQuery.Append(objclsCommon.GetAllBatchWithStockQuery(itemcode, whscode));

                                        oMatrix = oForm.Items.Item("mtx1").Specific;
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.rowTable);
                                        SAPbobsCOM.Recordset oRs = objclsCommon.returnRecord(sbQuery.ToString());
                                        int row = 0;
                                        while (!oRs.EoF)
                                        {
                                            oDbDataSource.InsertRecord(oDbDataSource.Size);
                                            oDbDataSource.SetValue("U_WhsCode", row, whscode);
                                            oDbDataSource.SetValue("U_BatchNo", row, oRs.Fields.Item("DistNumber").Value.ToString());
                                            oDbDataSource.SetValue("U_StkQty", row, oRs.Fields.Item("Stock").Value.ToString());

                                            oRs.MoveNext();
                                            row++;
                                        }
                                        oMatrix.LoadFromDataSource();


                                    }
                                    //    sbQuery.Append(" SELECT \"" + productCodeUDF + "\",\"" + productNameUDF + "\",\"" + matrixTareWtUDF + "\",");
                                    //    sbQuery.Append(" \"" + matrixBarCodeUDF + "\",\"" + matrixNetWtUDF + "\",\"" + matrixGrossWtUDF + "\"  ");
                                    //    sbQuery.Append(" FROM \"" + headerTable + "\" T0");
                                    //    sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\"  = T1.\"DocEntry\" ");
                                    //    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "' AND T1.\"LineId\" = '" + lineId + "'");

                                    //    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    //    if (!oRs.EoF)
                                    //    {
                                    //        oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQCParameter.headerTable);

                                    //        itemCode = oRs.Fields.Item(productCodeUDF).Value;
                                    //        oDbDataSource.SetValue(clsWeighingScaleQCParameter.baseLineUDF, 0, lineId);
                                    //        oDbDataSource.SetValue(productCodeUDF, 0, oRs.Fields.Item(productCodeUDF).Value);
                                    //        oDbDataSource.SetValue(productNameUDF, 0, oRs.Fields.Item(productNameUDF).Value);
                                    //        oDbDataSource.SetValue(matrixBarCodeUDF, 0, oRs.Fields.Item(matrixBarCodeUDF).Value);
                                    //        oDbDataSource.SetValue(matrixTareWtUDF, 0, oRs.Fields.Item(matrixTareWtUDF).Value);
                                    //        oDbDataSource.SetValue(matrixNetWtUDF, 0, oRs.Fields.Item(matrixNetWtUDF).Value);
                                    //        oDbDataSource.SetValue(matrixGrossWtUDF, 0, oRs.Fields.Item(matrixGrossWtUDF).Value);
                                    //    }
                                    //    objclsComman.ReleaseObject(oRs);

                                    //    string qcSpecHeaderTable = "@QCSPEC";
                                    //    string qcSpecRowTable = "@QCSPEC1";

                                    //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    //    oMatrix.FlushToDataSource();
                                    //    oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQCParameter.rowTable);
                                    //    oDbDataSource.Clear();
                                    //    sbQuery.Length = 0;
                                    //    sbQuery.Append(" SELECT \"U_ParaCode\",\"U_ParaName\",\"U_MinValue\",\"U_MaxValue\",\"U_StdValue\",\"U_TolPer\",\"U_MethAna\",\"U_Unit\" ");
                                    //    sbQuery.Append(" FROM \"" + qcSpecHeaderTable + "\" T0 ");
                                    //    sbQuery.Append(" INNER JOIN \"" + qcSpecRowTable + "\" T1 ON T0.\"Code\" = T1.\"Code\" ");
                                    //    sbQuery.Append(" WHERE T0.\"" + productCodeUDF + "\" = '" + itemCode + "' ");

                                    //    oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    //    int row = 0;
                                    //    while (!oRs.EoF)
                                    //    {
                                    //        oDbDataSource.InsertRecord(oDbDataSource.Size);
                                    //        oDbDataSource.SetValue("U_ParaCode", row, oRs.Fields.Item("U_ParaCode").Value);
                                    //        oDbDataSource.SetValue("U_ParaName", row, oRs.Fields.Item("U_ParaName").Value);
                                    //        oDbDataSource.SetValue("U_MinValue", row, oRs.Fields.Item("U_MinValue").Value);
                                    //        oDbDataSource.SetValue("U_MaxValue", row, oRs.Fields.Item("U_MaxValue").Value);
                                    //        oDbDataSource.SetValue("U_StdValue", row, oRs.Fields.Item("U_StdValue").Value);
                                    //        oDbDataSource.SetValue("U_TolPer", row, oRs.Fields.Item("U_TolPer").Value);
                                    //        oDbDataSource.SetValue("U_MethAna", row, oRs.Fields.Item("U_MethAna").Value);
                                    //        oDbDataSource.SetValue("U_Unit", row, oRs.Fields.Item("U_Unit").Value);

                                    //        oRs.MoveNext();
                                    //        row++;
                                    //    }
                                    //    oMatrix.LoadFromDataSource();
                                    //    objclsComman.ReleaseObject(oRs);
                                    //}
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;
                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == "CFL_FGCODE")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_FGCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_FGName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_PlanQty", 0, "1");
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WhsCode")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                            }

                            else if (oCFLEvento.ChooseFromListUID == "CFL_RMCODE")
                            {

                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_RMCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue("U_RMName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue("U_RMType", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString());
                                oDbDataSource.SetValue("U_UOM", pVal.Row - 1, oDataTable.GetValue(CommonFields.InvntryUom, 0).ToString());
                                oDbDataSource.SetValue("U_BatchNo", pVal.Row - 1, "0");

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            else if (oCFLEvento.ChooseFromListUID == "CFL_WhsCode2")
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                                string whscode = oDataTable.GetValue(CommonFields.WhsCode, 0).ToString();
                                string itemcode = oDbDataSource.GetValue("U_RMCode", pVal.Row - 1).ToString();
                                string mixQty = oDbDataSource.GetValue("U_MixQty", pVal.Row - 1).ToString();
                                double dblMixQty = mixQty == string.Empty ? 0 : double.Parse(mixQty);
                                double dblAvgCost = objclsCommon.GetAverageCost(itemcode, whscode);

                                oDbDataSource.SetValue("U_PerUCost", pVal.Row - 1, dblAvgCost.ToString());
                                oDbDataSource.SetValue("U_TotalV", pVal.Row - 1, (dblMixQty * dblAvgCost).ToString());

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                                if (oForm.Mode == BoFormMode.fm_OK_MODE)
                                {
                                    oForm.Mode = BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                        }


                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.FormTypeEx == formTypEx && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    return;
                                }

                            }

                        }
                        #endregion

                        #region F_ItemChanged

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "U_PlanQty")
                            {
                                CalcAllRowMix();
                            }
                            else if (pVal.ItemUID == "mtx1")
                            {
                                if (pVal.ColUID == "U_MixPer")
                                {
                                    CalcRowMix_BasedOn_Per(pVal.Row);
                                }
                                else if (pVal.ColUID == "U_MixQty")
                                {
                                    CalcRowMix_BasedOn_Qty(pVal.Row);
                                }
                            }
                        }

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrix1UID, rowTable, matrix1PrimaryUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrix1UID, rowTable, matrix1PrimaryUDF);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                    }
                    //else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    //{
                    //    objclsComman.FillCombo_Series_Custom(oForm, "", "");
                    //    DisableControls(oForm.UniqueID);
                    //}
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        #region LoadForm

        private void LoadForm(string MenuID)
        {
            try
            {
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                    oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);
                    oCombo = oForm.Items.Item("U_Unit").Specific;
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetUnitQuery());

                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.AddRow(1, 1);
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RMType", 1);
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetItemGroupQuery());
                }

                oMatrix = oForm.Items.Item("mtx1").Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("U_FGCode").EnableinAddMode();

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_Date").Specific;
                    oEdit.String = "t";

                    objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_Date", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                    //string planNo = AutoPlanNo();
                    //oForm.DataSources.DBDataSources.Item(headerTable).SetValue(planNoUDF, 0, planNo);
                }
                catch { }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalcRowMix_BasedOn_Per(int row)
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            string rowMixPer = oDbDataSource.GetValue("U_MixPer", row - 1);
            double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

            double dblRowMixQty = dblPlannedQty * dblRowMixPer / 100;
            oDbDataSource.SetValue("U_MixQty", row - 1, dblRowMixQty.ToString());

            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void CalcRowMix_BasedOn_Qty(int row)
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            string rowMixQty = oDbDataSource.GetValue("U_MixQty", row - 1);
            double dblRowMixQty = rowMixQty == string.Empty ? 0 : double.Parse(rowMixQty);

            double dblRowMixPer = dblRowMixQty * 100 / dblPlannedQty;
            oDbDataSource.SetValue("U_MixPer", row - 1, dblRowMixPer.ToString());

            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void CalcAllRowMix()
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowMixPer = oDbDataSource.GetValue("U_MixPer", i);
                double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

                double dblRowMixQty = dblPlannedQty * dblRowMixPer / 100;
                oDbDataSource.SetValue("U_MixQty", i, dblRowMixQty.ToString());

                string rowPerUnitCost = oDbDataSource.GetValue("U_PerUCost", i);
                double dblRowPerUnitCost = rowPerUnitCost == string.Empty ? 0 : double.Parse(rowPerUnitCost);

                oDbDataSource.SetValue("U_TotalV", i, (dblRowMixQty * dblRowPerUnitCost).ToString());

            }
            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void GetTotalMix()
        {
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            double dblTotalMixPer = 0;
            double dblTotalMixQuality = 0;

            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowMixPer = oDbDataSource.GetValue("U_MixPer", i);
                double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

                string rowMixQuality = oDbDataSource.GetValue("U_MixQty", i);
                double dblRowMixQuality = rowMixQuality == string.Empty ? 0 : double.Parse(rowMixQuality);
                dblTotalMixPer = dblTotalMixPer + dblRowMixPer;
                dblTotalMixQuality = dblTotalMixQuality + dblRowMixQuality;
            }

            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotMPer", 0, dblTotalMixPer.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotMQ", 0, dblTotalMixQuality.ToString());

        }

        #endregion
    }
}
