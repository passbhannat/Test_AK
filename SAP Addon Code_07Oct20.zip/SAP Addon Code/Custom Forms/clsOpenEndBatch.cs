using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;
using SAPAddonCode.Custom_Forms;

namespace SAPAddonCode
{
    class clsOpenEndBatch : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.DBDataSource oDbDataSource1 = null;

        clsCommon objclsComman = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "OPENENDBATCH";
        public const string formTypEx = "OPENENDBATCH";
        const string formTitle = "Open End Formulation Batch";
        public const string headerTable = "@OPENENDBATCH";
        public const string rowTable = "@OPENENDBATCH1";
        const string objType = "OPENENDBATCH";

        string CFL_BP = nameof(CFL_BP);

        const string processCodeUDF = "U_PrcCode";
        const string processCodeUID = "PrcCode";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == "1")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string reqQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BaseQty", 0).ToString().Trim();
                                    double dblReqQty = reqQty == string.Empty ? 0 : double.Parse(reqQty);

                                    string totalQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalQty", 0).ToString().Trim();
                                    double dblTotalQty = totalQty == string.Empty ? 0 : double.Parse(totalQty);

                                    if (dblReqQty != dblTotalQty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Total quantity should be equal to required quantity", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = oForm.Items.Item("mtx1").Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                                    for (int i = 0; i < oDbDataSource1.Size; i++)
                                    {
                                        double dblStockQty = double.Parse(oDbDataSource1.GetValue("U_StkQty", i).ToString());
                                        double dblQty = double.Parse(oDbDataSource1.GetValue("U_Qty", i).ToString());
                                        if (dblQty > dblStockQty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Quantity should be equal to or less than Stock quantity. For Row: " + (i+1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {
                                return;
                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }

                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {

                        #region F_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypEx)
                                {
                                    if (pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).ToString();
                                        if (code.Trim() == string.Empty)
                                        {
                                            oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel)).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            oForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                            oForm.Select();
                                            objclsComman.RefreshRecord();
                                        }
                                    }
                                }
                            }

                        }
                        #endregion

                        #region F_ItemChanged

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "mtx1")
                            {
                                if (pVal.ColUID == "U_Qty")
                                {
                                    GetTotal();
                                }
                            }
                        }

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (pVal.BeforeAction == true)
            {
                oForm = oApplication.Forms.ActiveForm;
                try
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = true " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            else
            {
                try
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }


        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        string baseEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BaseEn", 0);
                        string baseLine = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BaseLine", 0);
                        string baseType = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_BaseType", 0);

                        sbQuery.Length = 0;
                        if (baseType == clsOpenEnd.objType)
                        {
                            sbQuery.Append(" UPDATE \"" + clsOpenEnd.rowTable + "\" SET \"U_BatchNo\" = '" + docEntry + "' WHERE \"DocEntry\" = '" + baseEntry + "' AND \"LineId\" = '" + baseLine + "'");
                        }
                        else if (baseType == clsRingSpun.objType)
                        {
                            sbQuery.Append(" UPDATE \"" + clsRingSpun.rowTable + "\" SET \"U_BatchNo\" = '" + docEntry + "' WHERE \"DocEntry\" = '" + baseEntry + "' AND \"LineId\" = '" + baseLine + "'");
                        }

                        objclsComman.SelectRecord(sbQuery.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        #region LoadForm

        public void LoadForm(string MenuID)
        {
            try
            {
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsComman.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }


        #endregion

        private void GetTotal()
        {
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            double dblTotalQuality = 0;

            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowQty = oDbDataSource.GetValue("U_Qty", i);
                double dblRowQty = rowQty == string.Empty ? 0 : double.Parse(rowQty);
                dblTotalQuality = dblTotalQuality + dblRowQty;
            }

            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotalQty", 0, dblTotalQuality.ToString());
        }

        #endregion
    }
}
