﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using SAPbouiCOM;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;

namespace SAPAddonCode.Custom_Forms
{
    class clsPackingList : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.DBDataSource oDbDataSource1 = null;
        clsCommon objclsComman = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "PACKINGLIST";
        const string formTypEx = "PACKINGLIST";
        const string formTitle = "Packing List";
        const string headerTable = "@PACKINGLIST";
        const string rowTable = "@PACKINGLIST1";

        const string objType = "PACKINGLIST";
        const string matrixUID1 = "mtx1";

        public void ItemEvent(ref ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.Before_Action == true
            if (pVal.Before_Action == true)
            {
                try
                {
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        #region Add Record
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                string CardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_CardCode", 0).ToString().Trim();
                                if (CardCode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Customer Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                            }
                        }
                        #endregion
                    }
                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.Before_Action == false

            else
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }
                        oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);

                        if (oCFLEvento.ChooseFromListUID == "CFL_CARDCODE")
                        {
                            oDbDataSource.SetValue("U_CardCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                            oDbDataSource.SetValue("U_CardName", 0, oDataTable.GetValue(CommonFields.CardName, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_ITEM")
                        {
                            oDbDataSource.SetValue("U_ItemCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE")
                        {
                            oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                    }
                    #endregion

                    #region F_pVal.ItemChanged == true
                    if (pVal.ItemChanged == true)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.ItemUID == "U_TotalNo")
                        {
                            string totalBag = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotalNo", 0).Trim();
                            double iTotalBag = totalBag == string.Empty ? 0 : int.Parse(totalBag);
                            oMatrix = oForm.Items.Item(matrixUID1).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource1.Clear();
                            for (int i = 0; i < iTotalBag; i++)
                            {
                                oDbDataSource1.InsertRecord(i);
                                oDbDataSource1.SetValue("LineId", i, (i + 1).ToString());
                            }
                            oMatrix.LoadFromDataSource();
                        }
                        else if (pVal.ItemUID == matrixUID1)
                        {
                            if (pVal.ColUID == "U_BagNo")
                            {
                                string itemcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ItemCode", 0).Trim();
                                if (itemcode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select itemcode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                oMatrix = oForm.Items.Item(matrixUID1).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource1 = oForm.DataSources.DBDataSources.Item(rowTable);
                                string bagNo = oDbDataSource1.GetValue("U_BagNo", pVal.Row - 1).ToString();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"U_LotNo\" ,T1.\"U_GrWt\",T1.\"U_TrWt\",T1.\"U_NetWt\"  ");
                                sbQuery.Append(" FROM \"" + clsBoxPacking.headerTable + "\" T0 ");
                                sbQuery.Append(" INNER JOIN \"" + clsBoxPacking.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\"  ");
                                sbQuery.Append(" WHERE T0.\"U_FGCode\" = '" + itemcode + "' AND T1.\"U_BagNo\" = '" + bagNo + "' ");
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                oForm.Freeze(true);
                                try
                                {
                                    if (oRs.RecordCount > 0)
                                    {
                                        oDbDataSource1.SetValue("U_LotNo", pVal.Row - 1, oRs.Fields.Item("U_LotNo").Value.ToString());
                                        oDbDataSource1.SetValue("U_GrWt", pVal.Row - 1, oRs.Fields.Item("U_GrWt").Value.ToString());
                                        oDbDataSource1.SetValue("U_NetWt", pVal.Row - 1, oRs.Fields.Item("U_NetWt").Value.ToString());
                                        oMatrix.LoadFromDataSource();
                                    }
                                }
                                catch { }
                                oForm.Freeze(false);
                                double dblTotalGrWt = 0;
                                double dblTotalNetWt = 0;

                                for (int i = 0; i < oDbDataSource1.Size; i++)
                                {
                                    double dblGrWt = double.Parse(oDbDataSource1.GetValue("U_GrWt", i).ToString());
                                    double dblNetWt = double.Parse(oDbDataSource1.GetValue("U_NetWt", i).ToString());

                                    dblTotalGrWt = dblTotalGrWt + dblGrWt;
                                    dblTotalNetWt = dblTotalNetWt + dblNetWt;
                                }
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotalGr", 0, dblTotalGrWt.ToString());
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotalNt", 0, dblTotalNetWt.ToString());
                            }
                        }
                    }
                    #endregion  

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

        }

        public void MenuEvent(ref MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    try
                    {
                        oForm = oApplication.Forms.ActiveForm;
                    }
                    catch { }
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                else
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        private void LoadForm(string MenuID)
        {
            try
            {
                if (MenuID == formMenuUID)
                {
                    string FormID;
                    if (objclsComman.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";

                    oCombo = oForm.Items.Item("U_Unit").Specific;
                    objclsComman.FillCombo(oCombo, objclsComman.GetUnitQuery());
                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;

                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_Status", 0, "O");

                #region Date,Series and DocNum

                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, objType, "U_DocDate", "Load");
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
    }
}
