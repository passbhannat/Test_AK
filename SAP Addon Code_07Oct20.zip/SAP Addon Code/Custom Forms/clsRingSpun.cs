﻿using SAPAddonCode.Classes;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using SAPAddonCode.Extensions;

namespace SAPAddonCode.Custom_Forms
{

    class clsRingSpun : Connection
    {
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsCommon = new clsCommon();
        StringBuilder sbQuery = new StringBuilder();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formMenuUID = "RINGSPUN";
        const string formTypEx = "RINGSPUN";
        const string formTitle = "Ring Spun Formulation";
        public const string headerTable = "@RINGSPUN";
        public const string rowTable = "@RINGSPUN1";
        public const string objType = "RINGSPUN";
        public const string ringSpunItemCode = "RSSFG";

        const string matrix1UID = "mtx1";
        const string rowTablePrimaryUDF1 = "U_RMCode";

        public void ItemEvent(ref ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            #region pVal.Before_Action == true
            if (pVal.Before_Action == true)
            {
                try
                {
                    #region T_et_ITEM_PRESSED
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                    {
                        #region Add Record
                        if (pVal.ItemUID == "1")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                            {
                                string mixcode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MixNo", 0).ToString().Trim();
                                if (mixcode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select Mixing No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string whscode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_WhsCode", 0).ToString().Trim();
                                if (whscode == string.Empty)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Please select warehouse code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string totalMixPer = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_TotMPer", 0).ToString().Trim();
                                double dblTotalMixPer = totalMixPer == string.Empty ? 0 : double.Parse(totalMixPer);
                                if (dblTotalMixPer != 100)
                                {
                                    BubbleEvent = false;
                                    oApplication.StatusBar.SetText("Total Mix percent should be 100", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oMatrix = oForm.Items.Item(matrix1UID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    string itemcode = oDbDataSource.GetValue("U_RMCode", i);
                                    if (itemcode != string.Empty)
                                    {
                                        whscode = oDbDataSource.GetValue("U_WhsCode", i);
                                        if (whscode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please select warehouse at Row : " + (i + 1).ToString(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        #endregion

                        else if (pVal.ItemUID == "btGen")
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (oForm.Mode != BoFormMode.fm_OK_MODE)
                            {
                                oApplication.StatusBar.SetText("Form should be in Ok Mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                return;
                            }
                            int i = oApplication.MessageBox("Do you really want to continue?", 2, "Yes", "No", "");
                            if (i == 1)
                            {
                                bool isRecordAdded = false;
                                if (Create_ProdcutionOrder_Special() == true)
                                {
                                    if (Create_IssueFromProduction(oForm.UniqueID) == true)
                                    {
                                        isRecordAdded = true;
                                    }
                                    if (isRecordAdded == true)
                                    {
                                        objclsCommon.RefreshRecord();
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #region T_et_MATRIX_LINK_PRESSED
                    else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED)
                    {
                        oForm = oApplication.Forms.Item(pVal.FormUID);

                        if (pVal.ItemUID == matrix1UID)
                        {
                            if (pVal.ColUID == "U_BatchNo")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (!(oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_VIEW_MODE))
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();

                                clsVariables.BaseFormUID = oForm.UniqueID;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(pVal.ItemUID).Specific;
                                oMatrix.FlushToDataSource();
                                string lineId = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(CommonFields.LineId, pVal.Row - 1).Trim();
                                string batchDocEntry = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(pVal.ColUID, pVal.Row - 1).Trim();
                                string itemcode = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_RMCode", pVal.Row - 1).Trim();
                                string itemname = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_RMName", pVal.Row - 1).Trim();
                                string qty = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_MixQty", pVal.Row - 1).Trim();
                                string whscode = oForm.DataSources.DBDataSources.Item(rowTable).GetValue("U_WhsCode", pVal.Row - 1).Trim();

                                batchDocEntry = batchDocEntry == string.Empty ? "0" : batchDocEntry;
                                clsOpenEndBatch obj = new clsOpenEndBatch();
                                obj.LoadForm(clsOpenEndBatch.formTypEx);
                                oForm = oApplication.Forms.ActiveForm;
                                if (batchDocEntry != "0")
                                {
                                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                                    oEdit.String = batchDocEntry;
                                    oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                else
                                {
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseEn", 0, docEntry);
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseLine", 0, lineId);
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseIC", 0, itemcode);
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseIN", 0, itemname);
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseQty", 0, qty);
                                    oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.headerTable).SetValue("U_BaseType", 0, objType);

                                    string itemCode = string.Empty;
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(objclsCommon.GetAllBatchWithStockQuery(itemcode, whscode));

                                    oMatrix = oForm.Items.Item("mtx1").Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(clsOpenEndBatch.rowTable);
                                    SAPbobsCOM.Recordset oRs = objclsCommon.returnRecord(sbQuery.ToString());
                                    int row = 0;
                                    while (!oRs.EoF)
                                    {
                                        oDbDataSource.InsertRecord(oDbDataSource.Size);
                                        oDbDataSource.SetValue("U_WhsCode", row, whscode);
                                        oDbDataSource.SetValue("U_BatchNo", row, oRs.Fields.Item("DistNumber").Value.ToString());
                                        oDbDataSource.SetValue("U_StkQty", row, oRs.Fields.Item("Stock").Value.ToString());

                                        oRs.MoveNext();
                                        row++;
                                    }
                                    oMatrix.LoadFromDataSource();


                                }
                            }
                        }
                    }
                    #endregion

                }
                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion

            #region pVal.Before_Action == false
            else if (pVal.Before_Action == false)
            {
                try
                {
                    #region F_et_CHOOSE_FROM_LIST
                    if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                    {
                        SAPbouiCOM.DataTable oDataTable = null;
                        oForm = oApplication.Forms.Item(pVal.FormUID);
                        SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                        oDataTable = oCFLEvento.SelectedObjects;
                        string sCFL_ID = oCFLEvento.ChooseFromListUID;
                        string Value = string.Empty;
                        if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                        {
                            return;
                        }
                        if (oCFLEvento.ChooseFromListUID == "CFL_MIXCODE")
                        {

                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_MixCode", 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_MixName", 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());

                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WHSCODE")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            oDbDataSource.SetValue("U_WhsCode", 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_RMCode")
                        {

                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_RMCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                            oDbDataSource.SetValue("U_RMName", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            oDbDataSource.SetValue("U_RMType", pVal.Row - 1, oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString());
                            oDbDataSource.SetValue("U_UOM", pVal.Row - 1, oDataTable.GetValue(CommonFields.InvntryUom, 0).ToString());
                            oDbDataSource.SetValue("U_BatchNo", pVal.Row - 1, "0");

                            if (pVal.Row == oMatrix.RowCount)
                            {
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                            }
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                        else if (oCFLEvento.ChooseFromListUID == "CFL_WhsCode2")
                        {
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx1").Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource.SetValue("U_WhsCode", pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                            if (pVal.Row == oMatrix.RowCount)
                            {
                                oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                int RowNo = 1;
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                    RowNo = RowNo + 1;
                                }
                            }
                            oMatrix.LoadFromDataSource();
                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            clsVariables.boolCFLSelected = true;
                            SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                            clsVariables.ColNo = oPos.ColumnIndex;
                            clsVariables.RowNo = oPos.rowIndex;
                        }
                    }
                    #endregion

                    #region F_ItemChanged

                    if (pVal.ItemChanged == true)
                    {
                        if (pVal.ItemUID == "U_PlanQty")
                        {
                            CalcAllRowMix();
                        }
                        else if (pVal.ItemUID == "mtx1")
                        {
                            if (pVal.ColUID == "U_MixPer")
                            {
                                CalcRowMix_BasedOn_Per(pVal.Row);
                            }
                            else if (pVal.ColUID == "U_MixQty")
                            {
                                CalcRowMix_BasedOn_Qty(pVal.Row);
                            }
                        }
                    }

                    #endregion
                }


                catch (Exception ex)
                {
                    oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                }
            }
            #endregion
        }

        public void MenuEvent(ref MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                #region pVal.BeforeAction == true
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                #endregion

                #region pVal.BeforeAction == false
                else
                {
                    try
                    {
                        if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                        {
                            LoadForm(pVal.MenuUID);
                        }
                        else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                        {
                            oForm = oApplication.Forms.ActiveForm;
                            AddRow(matrix1UID, rowTable, rowTablePrimaryUDF1);
                        }
                        else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                        {
                            oForm = oApplication.Forms.ActiveForm;
                            DeleteRow(matrix1UID, rowTable, rowTablePrimaryUDF1);
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Menu Event: Before Action = false" + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        objclsCommon.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"" + rowTablePrimaryUDF1 + "\" IS NULL ");
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        private void LoadForm(string MenuID)
        {

            try
            {
                if (MenuID == formMenuUID)

                {
                    string FormID;
                    if (objclsCommon.FormAlreadyExist(MenuID, out FormID) == true)
                    {
                        oForm = oApplication.Forms.Item(FormID);
                        oForm.Select();
                        return;
                    }
                    objclsCommon.LoadXML(MenuID, "DocNum", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu("1292", true);
                    oForm.EnableMenu("1293", true);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oForm.Items.Item("fld1").Click(BoCellClickType.ct_Regular);
                    oCombo = oForm.Items.Item("U_Unit").Specific;
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetUnitQuery());

                    oMatrix = oForm.Items.Item("mtx1").Specific;
                    oMatrix.AddRow(1, 1);

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("U_RMType", 1);
                    objclsCommon.FillCombo(oCombo, objclsCommon.GetItemGroupQuery());
                }
                oForm.Items.Item("DocEntry").EnableinFindMode();
                oForm.Items.Item("DocNum").EnableinFindMode();
                oForm.Items.Item("U_SFGPONo").EnableinFindMode();
                oForm.Items.Item("U_SFGIssNo").EnableinFindMode();
                 
                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("U_DocDate").Specific;
                    oEdit.String = "t";

                    objclsCommon.FillCombo_Series_Custom(oForm, objType, "U_DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_DocNo", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("LoadForm:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsCommon.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void CalcRowMix_BasedOn_Per(int row)
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            string rowMixPer = oDbDataSource.GetValue("U_MixPer", row - 1);
            double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

            double dblRowMixQty = dblPlannedQty * dblRowMixPer / 100;
            oDbDataSource.SetValue("U_MixQty", row - 1, dblRowMixQty.ToString());

            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void CalcRowMix_BasedOn_Qty(int row)
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            string rowMixQty = oDbDataSource.GetValue("U_MixQty", row - 1);
            double dblRowMixQty = rowMixQty == string.Empty ? 0 : double.Parse(rowMixQty);

            double dblRowMixPer = dblRowMixQty * 100 / dblPlannedQty;
            oDbDataSource.SetValue("U_MixPer", row - 1, dblRowMixPer.ToString());

            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void CalcAllRowMix()
        {
            oForm = oApplication.Forms.ActiveForm;
            string plannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PlanQty", 0).Trim();
            double dblPlannedQty = plannedQty == string.Empty ? 0 : double.Parse(plannedQty);
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowMixPer = oDbDataSource.GetValue("U_MixPer", i);
                double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

                double dblRowMixQty = dblPlannedQty * dblRowMixPer / 100;
                oDbDataSource.SetValue("U_MixQty", i, dblRowMixQty.ToString());

                string rowPerUnitCost = oDbDataSource.GetValue("U_PerUCost", i);
                double dblRowPerUnitCost = rowPerUnitCost == string.Empty ? 0 : double.Parse(rowPerUnitCost);

                oDbDataSource.SetValue("U_TotalV", i, (dblRowMixQty * dblRowPerUnitCost).ToString());

            }
            oMatrix.LoadFromDataSource();
            GetTotalMix();
        }

        private void GetTotalMix()
        {
            oForm = oApplication.Forms.ActiveForm;
            oMatrix = oForm.Items.Item("mtx1").Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            double dblTotalMixPer = 0;
            double dblTotalMixQuality = 0;

            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string rowMixPer = oDbDataSource.GetValue("U_MixPer", i);
                double dblRowMixPer = rowMixPer == string.Empty ? 0 : double.Parse(rowMixPer);

                string rowMixQuality = oDbDataSource.GetValue("U_MixQty", i);
                double dblRowMixQuality = rowMixQuality == string.Empty ? 0 : double.Parse(rowMixQuality);
                dblTotalMixPer = dblTotalMixPer + dblRowMixPer;
                dblTotalMixQuality = dblTotalMixQuality + dblRowMixQuality;
            }

            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotMPer", 0, dblTotalMixPer.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_TotMQ", 0, dblTotalMixQuality.ToString());

        }

        private bool Create_ProdcutionOrder_Special()
        {
            oForm = oApplication.Forms.ActiveForm;
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            SAPbobsCOM.Recordset oRs = null;
            string lineId = string.Empty;
            int childRow = 0;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ");
            sbQuery.Append(" T0.\"U_DocDate\", T0.\"U_PlanQty\", T0.\"U_WhsCode\", T0.\"U_MixNo\"  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
            sbQuery.Append(" AND IFNULL(T0.\"U_SFGPOEn\",'') = '' ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            if (oRs.RecordCount == 0)
            {
                //oApplication.StatusBar.SetText("SFG PO already created", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                return true;
            }

            SAPbobsCOM.ProductionOrders oDocument = (SAPbobsCOM.ProductionOrders)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

            while (!oRs.EoF)
            {
                #region Header

                oDocument.StartDate = DateTime.Parse(oRs.Fields.Item("U_DocDate").Value.ToString());
                oDocument.DueDate = DateTime.Parse(oRs.Fields.Item("U_DocDate").Value.ToString());
                oDocument.PostingDate = DateTime.Parse(oRs.Fields.Item("U_DocDate").Value.ToString());
                oDocument.ProductionOrderType = SAPbobsCOM.BoProductionOrderTypeEnum.bopotSpecial;
                oDocument.ProductionOrderStatus = SAPbobsCOM.BoProductionOrderStatusEnum.boposPlanned;
                oDocument.ItemNo = ringSpunItemCode;
                oDocument.Warehouse = oRs.Fields.Item("U_WhsCode").Value;
                oDocument.PlannedQuantity = oRs.Fields.Item("U_PlanQty").Value;

                #endregion

                #region RM Items


                sbQuery = new StringBuilder();

                sbQuery.Append(" SELECT ");
                sbQuery.Append(" T0.\"U_RMCode\", T0.\"U_MixQty\", T0.\"U_MixPer\", T0.\"U_WhsCode\"  ");
                sbQuery.Append(" FROM \"" + rowTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\"   ");
                sbQuery.Append(" WHERE T1.\"DocEntry\" = '" + formDocEntry + "'  ");
                sbQuery.Append(" AND IFNULL(T0.\"U_RMCode\",'') != '' ");

                SAPbobsCOM.Recordset oRsRM = objclsCommon.returnRecord(sbQuery.ToString());
                while (!oRsRM.EoF)
                {
                    oDocument.Lines.SetCurrentLine(childRow);
                    oDocument.Lines.ItemNo = oRsRM.Fields.Item("U_RMCode").Value.ToString();
                    oDocument.Lines.Warehouse = oRsRM.Fields.Item("U_WhsCode").Value.ToString();
                    oDocument.Lines.ProductionOrderIssueType = SAPbobsCOM.BoIssueMethod.im_Manual;
                    oDocument.Lines.PlannedQuantity = double.Parse(oRsRM.Fields.Item("U_MixQty").Value.ToString());
                    oDocument.Lines.Add();
                    childRow++;
                    oRsRM.MoveNext();
                }
                #endregion


                oRs.MoveNext();
            }
            int retVal = oDocument.Add();
            if (retVal != 0)
            {
                oApplication.StatusBar.SetText("Production Order Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
            else
            {
                string PODocEntry = oCompany.GetNewObjectKey();
                objclsCommon.ConvertProductionOrder_To_Release(Int32.Parse(PODocEntry));
                string PODocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OWOR WHERE \"DocEntry\" = '" + PODocEntry + "'");
                objclsCommon.SelectRecord("UPDATE T0 SET \"U_SFGPOEn\" = '" + PODocEntry + "',\"U_SFGPONo\" = '" + PODocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "'  ");
                oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                return true;
            }
        }

        private bool Create_IssueFromProduction(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
            string poDocEntry = objclsCommon.SelectRecord("SELECT \"U_SFGPOEn\" FROM \"" + headerTable + "\" T0 WHERE T0.\"DocEntry\" = '" + formDocEntry + "' ");

            SAPbobsCOM.Recordset oRs = null;
            string lineId = string.Empty;
            int childRow = 0;

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT ");
            sbQuery.Append(" T0.\"U_DocDate\",  T0.\"U_MixNo\"  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + formDocEntry + "'  ");
            sbQuery.Append(" AND IFNULL(T0.\"U_SFGIssEn\",'') = '' ");
            oRs = objclsCommon.returnRecord(sbQuery.ToString());

            if (oRs.RecordCount == 0)
            {
                return true;
            }
            SAPbobsCOM.Documents oDocument = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit);
            try
            {
                while (!oRs.EoF)
                {
                    #region Header

                    oDocument.DocDate = DateTime.Parse(oRs.Fields.Item("U_DocDate").Value.ToString());

                    #endregion
                    string mixNo = oRs.Fields.Item("U_MixNo").Value.ToString();

                    sbQuery = new StringBuilder();

                    sbQuery.Append(" SELECT T0.\"ItemCode\",T0.\"PlannedQty\",T0.\"LineNum\",T1.\"ManBtchNum\" ");
                    sbQuery.Append(" FROM WOR1 T0 ");
                    sbQuery.Append(" INNER JOIN OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                    sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + poDocEntry + "' ");
                    SAPbobsCOM.Recordset oRsItem = objclsCommon.returnRecord(sbQuery.ToString());
                    while (!oRsItem.EoF)
                    {
                        if (childRow > 0)
                        {
                            oDocument.Lines.Add();
                        }
                        oDocument.Lines.SetCurrentLine(childRow);
                        oDocument.Lines.BaseEntry = Int32.Parse(poDocEntry);
                        oDocument.Lines.BaseType = 202;
                        oDocument.Lines.BaseLine = int.Parse(oRsItem.Fields.Item("LineNum").Value.ToString());

                        string itemcode = oRsItem.Fields.Item("ItemCode").Value.ToString();
                        //string batchDocEntry = oRsItem.Fields.Item("U_BatchNo").Value.ToString();
                        string manBatch = oRsItem.Fields.Item("ManBtchNum").Value.ToString();
                        double plannedQty = double.Parse(oRsItem.Fields.Item("PlannedQty").Value.ToString());
                        if (manBatch == "Y")
                        {
                            oDocument.Lines.BatchNumbers.InternalSerialNumber = mixNo; 
                            oDocument.Lines.BatchNumbers.BatchNumber = mixNo; 
                            oDocument.Lines.BatchNumbers.Quantity = plannedQty;
                        }

                        childRow++;
                        oRsItem.MoveNext();
                    }
                    oRs.MoveNext();
                }
                int retVal = oDocument.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Issue For Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return false;
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsCommon.SelectRecord("SELECT \"DocNum\" FROM OIGE WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    objclsCommon.SelectRecord("UPDATE T0 SET \"U_SFGIssEn\" = '" + newDocEntry + "',\"U_SFGIssNo\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + formDocEntry + "'  ");
                    oApplication.StatusBar.SetText("Issue For Production No " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    return true;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Issue For Production Error: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
        }

    }
}