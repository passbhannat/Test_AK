using SAPAddonCode;
using SAPAddonCode.Classes;
using SAPAddonCode.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;
using SAPAddonCode.Custom_Forms;
using SAPAddonCode.Standard_Forms;

namespace SAPAddonCode.Classes
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();
        clsOpenEnd _clsOpenEnd = new clsOpenEnd();
        clsOpenEndBatch _clsOpenEndBatch = new clsOpenEndBatch();

        clsRingSpun _clsRingSpun = new clsRingSpun();
        clsBoxPacking _clsBoxPacking = new clsBoxPacking();
        clsCottonTransfer _clsCottonTransfer = new clsCottonTransfer();
        clsRecProd _clsRecProd = new clsRecProd();
        clsPackingList _clsPackingList = new clsPackingList();
        clsVisaDetails _clsVisaDetails = new clsVisaDetails();

        clsDelivery _clsDelivery = new clsDelivery();


        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            // 8192 - System Initialisation
            // 43520 - Main Menu
            objclsComman.AddMenu(BoMenuType.mt_STRING, "8192", "UDO", "Create UDO", 5);
            objclsComman.AddMenu(BoMenuType.mt_POPUP, "43520", "PROD_PLAN", "Production Planning", 16);

            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "OPENEND", "Open End Mixing Formulation", 0);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "RINGSPUN", "Ring Spun Formulation", 1);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "RECPROD", "Reciept From Production", 2);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "BOXPACKING", "Box Packing", 3);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "PACKINGLIST", "Packing List", 4);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "COTTONTRANSFER", "Cotton Transfer", 5);
            objclsComman.AddMenu(BoMenuType.mt_STRING, "PROD_PLAN", "VISADETAILS", "Visa Details", 6);
        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
        }


        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.FormTypeEx == "OPENEND")
                {
                    _clsOpenEnd.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "OPENENDBATCH")
                {
                    _clsOpenEndBatch.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "RINGSPUN")
                {
                    _clsRingSpun.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "BOXPACKING")
                {
                    _clsBoxPacking.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "RECPROD")
                {
                    _clsRecProd.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "COTTONTRANSFER")
                {
                    _clsCottonTransfer.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "PACKINGLIST")
                {
                    _clsPackingList.ItemEvent(ref pVal, out BubbleEvent);
                }
                else if (pVal.FormTypeEx == "VISADETAILS")
                {
                    _clsVisaDetails.ItemEvent(ref pVal, out BubbleEvent);
                }
               else if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
                {
                    _clsDelivery.ItemEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            SAPbouiCOM.Form oForm = null;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == "UDO")
                    {
                        oApplication.StatusBar.SetText("Please wait....", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                if (pVal.MenuUID == "OPENEND" || (oForm != null && oForm.TypeEx == "OPENEND"))
                {
                    _clsOpenEnd.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "RINGSPUN" || (oForm != null && oForm.TypeEx == "RINGSPUN"))
                {
                    _clsRingSpun.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "BOXPACKING" || (oForm != null && oForm.TypeEx == "BOXPACKING"))
                {
                    _clsBoxPacking.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "COTTONTRANSFER" || (oForm != null && oForm.TypeEx == "COTTONTRANSFER"))
                {
                    _clsCottonTransfer.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "RECPROD" || (oForm != null && oForm.TypeEx == "RECPROD"))
                {
                    _clsRecProd.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "PACKINGLIST" || (oForm != null && oForm.TypeEx == "PACKINGLIST"))
                {
                    _clsPackingList.MenuEvent(ref pVal, out BubbleEvent);
                }
                if (pVal.MenuUID == "VISADETAILS" || (oForm != null && oForm.TypeEx == "VISADETAILS"))
                {
                    _clsVisaDetails.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.FormTypeEx == "OPENENDBATCH")
                {
                    _clsOpenEndBatch.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == "RINGSPUN")
                {
                    _clsRingSpun.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == "RECPROD")
                {
                    _clsRecProd.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
                else if (BusinessObjectInfo.FormTypeEx == "BOXPACKING")
                {
                    _clsBoxPacking.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
